/**
 *
 * Manipulating the DOM exercise.
 * Exercise programmatically builds navigation,
 * scrolls to anchors from navigation,
 * and highlights section in viewport upon scrolling.
 *
 * Dependencies: None
 *
 * JS Version: ES2015/ES6
 *
 * JS Standard: ESlint
 *
*/

/**
 * Define Global Variables
 *
*/

const sections = document.querySelectorAll("section"); // returns a node list of sections
const lists = document.getElementsByTagName('li')
const headerBar = document.getElementById('navbar__list'); // gets the id of the navigation bar at the top
const backToTop = document.getElementById('btn'); // for the button

/*
 * End Global Variables
*/

/*
  * Helping Functions
*/

/*
  * The button behaviour is set
    it gets the viewport to the top of the page
*/
const scrollToTop = function (){
  let yPos = window.scrollY;
  if ( yPos > 0){
    backToTop.className = "back-to-top show"
  }
  else {
    backToTop.className = "back-to-top hide"
  }
}

window.addEventListener('scroll', scrollToTop) // listens for the scroll to show the button

/*
 * Adding the sections in the nav bar
*/

sections.forEach(function(element, index, array){
  const num = index + 1
  const butContent = element.getAttribute("data-nav");
  const li = document.createElement('li')
  li.textContent = butContent
  headerBar.appendChild(li)
  li.addEventListener('click', function smoothScroll (){
    element.scrollIntoView({behavior: "smooth", block: "end", inline: "nearest"});
  });
/*
  * Highlighting the section currently in the viewport
*/
  const addActiveClass = function (){
  const secTop = element.getBoundingClientRect().top;
  if (secTop >= 0 && secTop <= 400){
    sections.forEach(function(elmnt, indx, ary){
      if (elmnt.classList.contains("your-active-class") === true) {
        elmnt.classList.remove("your-active-class");
      };
    });
      element.classList.add("your-active-class");
    Array.from(lists).forEach(function(element, index, array){
      if (element.classList.contains('your-active-class') === true){
        element.classList.remove('your-active-class');
      }
    });
    if (element.classList.contains('your-active-class') === true){
      lists[index].classList.add('your-active-class');
    }
  }
  }
  window.addEventListener('scroll', addActiveClass)
});
