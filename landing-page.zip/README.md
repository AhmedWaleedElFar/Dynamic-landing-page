# Project Title

Landing Page using HTML, CSS and Javascript
===========================================




## Table of Contents

* - Installation
* - Courses
* - Usage
* - Development
* - Contribute




## Installation

A **ZIP file** will be submitted containing the files with the following
solid structure:

> css
>> styles.css
> js
>> app.js
>> README.md
> index.html

Download the file and unzip it. The files will be there!




## Courses

The following is a list of the courses associated with the project.

* C1 - HTML
* C2 - CSS, Website Layout, Website Components
* C3 - JavaScript & The DOM




## Usage

This webpage is a testing for the skills acquired by the courses in this program.
A testing landing page which consists of 4 sections and a navigation bar which helps
scrolling through the page.




## Development

Three files : **index.html**, **styles.css** and **app.js**


### index.html:

    No changes in coding happened in this file. Only an extra section was added to prove
    the efficiency of the javascript code.


### styles.css:

    Changes made in this file to edit in the style of the elements in the webpage.
    The navigation bar style has been edited by selecting the "li" element and editing in
    the background and the font color style of the active element.


### app.js:

    The file was empty at first, with a bunch of comments placed as a guide.

    The global Variables, which were used in the whole javascript code, were defined.
    The variables are :

      - *sections* :
        >> which is a NodeList of all ***section*** elements

      - *lists* :
        >> which is a NodeList of all ***list*** elements

      - *headerBar* :
        >> which is the element which holds the id "***navbar__list***" (i.e the top navigation bar)

      - *backToTop* :
        >> which is an anchored location in the header for the button to return to when it is clicked.

      As for the functions, many functions were defined and were used in the webpage to make it dynamic.
      The functions are :

        - *scrollToTop* :
          This function was declared to detect the viewport and determine whether the "back-to-top" button
          would appear or not. If the webpage is at the top of the page or the webpage was loaded for the first time,
          the button would be hidden, but if you moved down the landing page, the button would appear after exactly 0.5 seconds
          of this event.

        - *smoothScroll* :
          This is actually a part of the "forEach()" loop on the sections NodeList which makes sure that when the buttons are clicked,
          the webpage dynamically and smoothly scrolls to the clicked section after assigning links for the sections in the Navigation
          bar in the heading.



        - *addActiveClass* :
          The main function behind detecting the active section and active link in the landing page.
          If one section of the four sections is in the viewport, the class of this section changes to "your-active-class" and by calling that
          function, the class is removed from any section and added to the section in the viewport. It also sets one of the links to the same class
          and make them unique other than the rest of the links. This function has managed to make the section in the viewport and its link highlighted
          simultaneously which achieves a more dynamic style and behaviour of the webpage.




## Contribute:
  Udacity
    > https://www.udacity.com/

  Atom Code Editor
    > https://atom.io/
